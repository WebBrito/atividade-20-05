function Dia() {
    const paragrafo = document.getElementById('resultado');
    let escolhausuario = document.getElementById('dia').Value;
    switch (escolhausuario) {
        case 'segunda':
            paragrafo.innerText = 'Hoje é segunda-feira';
            break;
        case 'terça':
            paragrafo.innerText = 'Hoje é terça-feira';
            break;
        case 'quarta':
            paragrafo.innerText = 'Hoje é quarta-feira';
            break;
        case 'quinta':
            paragrafo.innerText = 'Hoje é quinta-feira';
            break;
        case 'sexta':
            paragrafo.innerText = 'Hoje é sexta-feira';
            break;
        case 'sábado':
            paragrafo.innerText = 'Hoje é sábado';
            break;
        case 'domingo':
            paragrafo.innerText = 'Hoje é domingo';
            

        default:
            paragrafo.innerText = 'Dia não encontrado';
    }
}
