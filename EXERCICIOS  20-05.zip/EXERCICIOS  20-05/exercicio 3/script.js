
   

    var nome = document.getElementById('nome').value;
    var email = document.getElementById('email').value;
    var senha = document.getElementById('senha').value;
    var confirmaSenha = document.getElementById('confirmaSenha').value;
  
    if (nome === '' || email === '' || senha === '' || confirmaSenha === '') {
     
    }
  
    if (senha < 8) {
    }

    if (senha === confirmaSenha) {
        alert('Formulário enviado com sucesso!');
  
    }
  
else{
    alert('formulario nao pode ser enviado')
}



